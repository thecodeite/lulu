-- cPanel mysql backup
GRANT USAGE ON *.* TO 'luluplew'@'localhost' IDENTIFIED BY PASSWORD '*328AEB98C0E2C9B4F1F42777A781A93A51CE2A94';
GRANT ALL PRIVILEGES ON `luluplew\_pclawts\_luluwp1`.* TO 'luluplew'@'localhost';
GRANT ALL PRIVILEGES ON `luluplew\_%`.* TO 'luluplew'@'localhost';
GRANT USAGE ON *.* TO 'luluplew_user1'@'localhost' IDENTIFIED BY PASSWORD '*F976CE350A7F3F5C56E6B8B6386328D695706896';
GRANT ALL PRIVILEGES ON `luluplew\_pclawts\_luluwp1`.* TO 'luluplew_user1'@'localhost';
